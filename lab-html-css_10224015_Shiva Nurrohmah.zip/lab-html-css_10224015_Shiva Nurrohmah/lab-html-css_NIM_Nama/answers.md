# Jawaban Praktikum: [Shiva Nurrohmah] (10224015)

> Ganti nama dan NIM di atas dengan data diri sendiri. Catatan hasil pengujian dan DevTools harus diisi berdasarkan pengamatan sendiri.

## Bagian 1: Pemanasan

1. Selector: `nav a.active:hover`. Deklarasi: `color: red;`. Property: `color`. Value: `red`. Pseudo-class: `:hover`.
2. Block secara default: `p`, `li`, `h2`. Inline secara default: `span`, `a`, `strong`.
3. Paragraf A dan B menjadi hijau. Selector `.box p` memilih elemen `p` di dalam elemen yang memiliki class `box`, termasuk paragraf B yang berada di dalam `section`. C dan D tidak cocok.
4. Warnanya merah karena selector `#title` memiliki specificity lebih tinggi daripada `.heading` dan `h1`.
5. Tag ditutup dengan urutan yang salah. Bentuk yang benar: `<p>Hello <strong>world</strong></p>`.

## Bagian 3: Prediksi Selector Golf

P1. Prediksi:
- (a) `Weekly hack nights.`: hijau, karena `section p` lebih spesifik daripada `p`.
- (b) `Bring your own laptop.`: oranye, karena `.note` lebih spesifik daripada `section p`.
- (c) `© 2026 Student Affairs`: biru, karena hanya cocok dengan selector `p`.

Setelah diuji (hasil sebenarnya):
- (a) Hijau.
- (b) Oranye.
- (c) Biru.

P2. Specificity tertinggi ke terendah:
1. `#tech p`
2. `.club p`
3. `main section p`
4. `p`

## Bagian 4: Box model

Q1 (content-box): Lebar dari tepi border kiri ke tepi border kanan = content 300px + padding kiri 16px + padding kanan 16px + border kiri 1px + border kanan 1px = **334px**. Margin tidak termasuk lebar kartu yang terlihat.

Q2 (border-box): Lebar dari tepi border kiri ke tepi border kanan menjadi **300px**. Area content menyusut agar padding dan border tetap berada di dalam lebar 300px. Margin 24px di setiap sisi tetap berada di luar ukuran tersebut.

Pengecekan DevTools:
- Content: [isi berdasarkan hasil DevTools]
- Padding: [isi berdasarkan hasil DevTools]
- Border: [isi berdasarkan hasil DevTools]
- Margin: [isi berdasarkan hasil DevTools]

## Bagian 5: Tabel debug

| # | Baris/perkiraan lokasi | Bug | Perbaikan | Cara menemukannya |
|---|---|---|---|---|
| 1 | CSS `body` | `colour` bukan nama property CSS yang valid | Ganti menjadi `color` | Membaca kode/DevTools |
| 2 | CSS `header` | Titik koma hilang setelah `background: #dbe7f3` sehingga deklarasi berikutnya ikut terbaca tidak benar | Tambahkan `;` setelah nilai background | Membaca kode/DevTools |
| 3 | Selector kartu | `.Card` tidak cocok dengan class `card` karena kapitalisasi berbeda | Gunakan `.card` | Membandingkan HTML dan CSS |
| 4 | CSS `#news-list` | `18 px` memiliki spasi yang tidak valid | Ganti menjadi `18px` | DevTools |
| 5 | CSS `footer` | `centre` bukan nilai yang valid untuk `text-align` | Ganti menjadi `center` | DevTools |
| 6 | Heading | `<h1>` ditutup dengan `</h2>` | Gunakan `</h1>` | W3C Validator/membaca kode |
| 7 | Link About | Tanda kutip pada `href` tidak lengkap | Gunakan `href="about.html"` | Validator/membaca kode |
| 8 | Gambar berita | Elemen `<img>` tidak memiliki atribut `alt` | Tambahkan teks alternatif yang bermakna | Validator/pemeriksaan aksesibilitas |
| 9 | Daftar berita | HTML memakai `id="newsList"` sedangkan CSS memakai `#news-list` | Samakan, misalnya gunakan `#newsList` di CSS | Membandingkan HTML dan CSS |

## Bagian 6: Tabel Code Review

| # | Baris/perkiraan lokasi | Masalah | Mengapa penting | Perbaikan saya |
|---|---|---|---|---|
| 1 | Awal dokumen | Tidak ada `<!DOCTYPE html>` | Browser dapat masuk ke quirks mode | Tambahkan deklarasi doctype |
| 2 | Elemen `html` | Tidak ada atribut `lang` | Membantu pembaca layar mengenali bahasa halaman | Tambahkan `lang="en"` karena konten contoh berbahasa Inggris |
| 3 | Elemen `head` | Tidak ada meta charset dan viewport | Encoding dan tampilan perangkat seluler kurang terdefinisi | Tambahkan meta charset UTF-8 dan viewport |
| 4 | Judul halaman | Judul menggunakan `div` dan `b`, bukan heading | Struktur dokumen kurang semantik dan aksesibel | Gunakan `h1` |
| 5 | Struktur halaman | Banyak `div` digunakan untuk bagian yang memiliki makna | Elemen semantik lebih menjelaskan fungsi setiap bagian | Gunakan `header`, `nav`, `main`, `section`, `form`, dan `footer` |
| 6 | CSS `.header` | Lebar tetap `1200px` | Bisa melebar keluar layar pada perangkat kecil | Gunakan `width: min(100% - 2rem, 960px)` atau `max-width` dan margin otomatis |
| 7 | CSS `.nav a` | Menggunakan `!important` | Membuat aturan lebih sulit ditimpa dan dirawat | Hapus `!important` dan atur specificity dengan wajar |
| 8 | CSS `.content` | Warna `#bbbbbb` pada latar putih berkontras rendah | Teks lebih sulit dibaca | Gunakan warna teks lebih gelap |
| 9 | CSS `.sidebar` | Aturan tidak digunakan oleh elemen mana pun | CSS tidak terpakai membingungkan | Hapus aturan yang tidak digunakan |
| 10 | Judul About/Contact | Menggunakan inline style | Gaya sulit dipelihara dan digunakan ulang | Gunakan `h2` dan aturan CSS |
| 11 | Formulir | Input tidak memiliki `label` yang terhubung | Pengguna teknologi bantu sulit mengetahui fungsi input | Tambahkan `label for` dan `id` yang sesuai |
| 12 | Kolom email | Menggunakan `type="text"` | Validasi email bawaan browser tidak digunakan | Gunakan `type="email"` |
| 13 | Gambar | Tidak memiliki `alt` | Informasi gambar tidak tersedia bagi pembaca layar | Tambahkan teks alternatif |
| 14 | Tombol | `onclick` inline hanya menampilkan alert, bukan mengirim formulir sungguhan | Perilaku dan markup bercampur; proses pengiriman tidak jelas | Gunakan elemen `form` dan tombol submit; jelaskan bahwa backend diperlukan untuk benar-benar mengirim data |
| 15 | Pengaturan jarak | Banyak `<br>` digunakan untuk membuat jarak | Jarak presentasi sebaiknya dikontrol lewat CSS | Gunakan margin dan padding CSS |

### Refleksi

1. Masalah yang paling sulit disadari hanya dari tampilan browser adalah masalah semantik dan aksesibilitas, seperti label input yang tidak terhubung dan gambar tanpa teks alternatif. Halaman dapat terlihat normal, tetapi pengguna pembaca layar bisa kesulitan memahami isinya.
2. Halaman yang terlihat berfungsi tetap perlu diperbaiki karena validitas, aksesibilitas, responsivitas, dan keterbacaan kode memengaruhi kualitas serta kemudahan pemeliharaan. Tampilan yang benar saja belum menjamin halaman dibuat dengan baik.
3. Sebelum mengumpulkan tugas, saya akan memeriksa struktur HTML, mencoba halaman pada ukuran layar berbeda, memeriksa CSS melalui DevTools, dan menjalankan W3C Validator.

## Bagian 7: Exit ticket

1. Aturan CSS terdiri dari selector yang memilih elemen dan blok deklarasi yang berisi property serta value untuk mengatur tampilannya.
2. Konsep yang masih ingin saya pelajari lebih lanjut adalah specificity, terutama ketika beberapa selector mengatur property yang sama.
3. Sekarang saya bisa menghubungkan file CSS eksternal ke HTML, menggunakan selector dasar, serta mengatur warna, jarak, dan layout halaman.
