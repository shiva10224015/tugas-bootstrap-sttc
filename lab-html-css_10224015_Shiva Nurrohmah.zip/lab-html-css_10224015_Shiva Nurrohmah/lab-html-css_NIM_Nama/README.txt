PRAKTIKUM WEB101 - HTML & CSS

1. Ganti nama dan NIM pada answers.md.
2. Buka folder ini di VS Code.
3. Buka profile.html di browser untuk memeriksa tampilan.
4. Jalankan profile.html dan review-fixed.html melalui W3C Validator.
5. Isi hasil DevTools berdasarkan pengamatanmu sendiri.
6. Simpan screenshot validator sebagai checkpoints/validator.png.
7. Periksa kembali semua file sebelum ZIP dikumpulkan.

Catatan: formulir menggunakan action="#" sebagai demonstrasi struktur HTML. Form ini belum mengirim pesan ke server karena tugas tidak menyediakan backend.
